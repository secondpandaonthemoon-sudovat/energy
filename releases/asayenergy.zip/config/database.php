<?php
return [
  'host' => 'localhost',
  'port' => 3306,
  'database' => 'ASAY_DB_ADI',
  'username' => 'ASAY_DB_KULLANICI',
  'password' => '',
  'charset' => 'utf8mb4',
];
